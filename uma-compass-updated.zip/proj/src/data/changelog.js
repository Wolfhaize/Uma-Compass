// Add new entries to the TOP of this array. Newest first.
// date format: 'YYYY-MM-DD'
export const CHANGELOG = [
  {
    version: '1.1.0',
    date: '2026-08-09',
    notes: [
      'Reduced base font sizes app-wide so the UI no longer needs zooming out to fit comfortably.',
      'Added a mirrored scrollbar at the top of the tournament bracket view, so wide brackets no longer force scrolling to the bottom to find it.',
      'Bracket rounds near the end now label themselves Finals / Semifinals / Quarterfinals instead of just a round number.',
      'Discord copy buttons for race results and podiums now include which uma won, not just the player running it.',
      'The schedule/results tab shows a banner (with the champion\'s name) as soon as a tournament\'s finals are complete.',
      'Added an "End tournament" action that marks a tournament completed without deleting it, plus a matching "Reopen" action.',
      'Tournament cards on the list page show a "Copy finals" shortcut once a tournament is completed.',
      'Activity log entries are now detailed — race results log the actual finish order (uma + player), and roster changes log what changed.',
      'Fixed the "Delete tournament" button styling in Settings (was squeezed into a circular icon button).',
      'Added a 777m-remaining marker on every track visual — the key accel checkpoint for skills like Oguri Cap\'s.',
      'Added an accuracy disclaimer + gametora.com link to the top of the Uma Kit Library.',
      'Tab title now flags the app as in beta.',
      'Added a Turf/Dirt surface filter to the Strategy Planner.',
      'Filled in real GitHub/Discord links across the footer and landing page, and added an Umalator attribution alongside the existing sheet credit on the Track Database.',
      'Added a GPLv3 LICENSE, removed the separate deploy doc, and general code cleanup (removed unused/placeholder files and stray dev notes).',
    ],
  },
  {
    version: '1.1.0-prev',
    date: '2026-07-17',
    notes: [
      'Added a "My Umas" pool (save umas from the Uma Kit Library, mirrors the track pool).',
      'Draft Board now shows saved umas and flags recommended umas you already have.',
      'Added "Mark as taken" for tracks and umas — greys them out and excludes them from Draft Board recommendations.',
      'Added a freeform notes box to the Draft Board (autosaves).',
      'Strategy Planner now asks for confirmation before bulk-adding to your real draft pool.',
    ],
  },
  {
    version: '1.0.0',
    date: '2026-07-15',
    notes: [
      'Initial release: Track Database, Draft Board, Strategy Planner, Uma Kit Library, Skill Sheet.',
    ],
  },
]
